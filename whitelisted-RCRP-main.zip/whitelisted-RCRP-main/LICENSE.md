Custom License for "(WL) River City Roleplay" Ultility Bot

Copyright (c) 2025 Bugkung1412, RCRP Development Team

Permission is hereby granted, free of charge, to any person using this software and its functionality *as inspiration only*, subject to the following conditions:

1. **Prohibited Actions**:
   - The source code, scripts, logic, structure, and implementation of this bot (hereafter referred to as "the Software") may **NOT** be copied, redistributed, modified, or reused in any form.
   - Reverse engineering or extracting source code for replication is strictly prohibited.

2. **Permitted Use**:
   - You are permitted to **use the ideas, features, or behavior** of this bot to inspire your own original work.
   - Any such inspired work must be built from your own codebase, without copying from the Software.

3. **Disclaimer**:
   - THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED.
   - IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES, OR LIABILITY ARISING FROM USE OF THE SOFTWARE OR DERIVATIVE INSPIRATIONS.

By using or referencing this bot, you agree to comply with the terms of this license.

