# Ready - Bot on Start System
This ready system is for bot whenever they restarted, or started. The file will be **RUN** when bot **RESTARTED**
Good to use for sending panel, debugging or something. 

 ⚠️ **WARNING**
 - Don't change eventHandler and index.js
 - Register Command (regcommand.js) is used for registering new command, don't remove.
