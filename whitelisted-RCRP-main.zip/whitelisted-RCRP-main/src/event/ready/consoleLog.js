const { panelSystem } = require("../../command/tickets/panelSystem");

module.exports = async (client) => {
    console.log(`🌍 ${client.user.tag} is online`)
    // await panelSystem(client, '1307099343492481034', '1265327493813112852')
};  