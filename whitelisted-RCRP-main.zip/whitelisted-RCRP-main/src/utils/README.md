# Utility
This is where all code will be export, and do the stuff.
Don't fix any of them cause this is needed, it use to register command and stuff

📋 **NOTE:**
- On `getLocalCommand.js` is actually now registering command **globally** and not **locally** anymore.
- It's recommended to change file to **Typescript** if your handler or index is **Typescript**

# Credit
Utility Source File - notunderctrl
